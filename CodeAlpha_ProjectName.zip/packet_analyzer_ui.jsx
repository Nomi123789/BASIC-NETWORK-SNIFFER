import { useState, useEffect, useRef, useCallback } from "react";

// ── Palette ──────────────────────────────────────────────────────────────────
const PALETTE = {
  bg:       "#0a0e1a",
  panel:    "#0f1626",
  border:   "#1e2d4a",
  accent:   "#00d4ff",
  accent2:  "#00ff88",
  warn:     "#ffaa00",
  danger:   "#ff4466",
  muted:    "#3a4a6a",
  text:     "#c8d8f8",
  dim:      "#5a6a8a",
};

const PROTO_STYLE = {
  TCP:  { bg: "#003366", fg: "#00aaff", border: "#0055cc" },
  UDP:  { bg: "#003322", fg: "#00cc88", border: "#009955" },
  ICMP: { bg: "#330033", fg: "#cc44ff", border: "#8800cc" },
  OTHER:{ bg: "#222",    fg: "#888",    border: "#444" },
};

const FLAG_COLORS = {
  SYN: "#00ff88", ACK: "#00aaff", PSH: "#00ccff",
  FIN: "#ffaa00", RST: "#ff4466", URG: "#ff88ff",
  ECE: "#888",    CWR: "#888",
};

const WELL_KNOWN_PORTS = {
  20:"FTP-Data",21:"FTP",22:"SSH",23:"Telnet",25:"SMTP",
  53:"DNS",67:"DHCP",80:"HTTP",110:"POP3",123:"NTP",
  143:"IMAP",161:"SNMP",443:"HTTPS",465:"SMTPS",514:"Syslog",
  587:"SMTP",993:"IMAPS",995:"POP3S",1433:"MSSQL",3306:"MySQL",
  3389:"RDP",5432:"PostgreSQL",5900:"VNC",6379:"Redis",8080:"HTTP-Alt",
  8443:"HTTPS-Alt",27017:"MongoDB",
};

const ICMP_TYPES = {
  0:"Echo Reply",3:"Dest Unreachable",8:"Echo Request",
  11:"Time Exceeded",5:"Redirect",
};

// ── Packet Generator ──────────────────────────────────────────────────────────
const SAMPLE_IPS = [
  "192.168.1.10","192.168.1.1","10.0.0.5","172.16.0.50",
  "8.8.8.8","1.1.1.1","93.184.216.34","52.86.12.45",
];
const SAMPLE_PORTS = [80,443,53,22,3306,8080,443,443,80,53,22,443];
const TCP_FLAG_COMBOS = [
  ["SYN"],["SYN","ACK"],["ACK"],["ACK","PSH"],["FIN","ACK"],["RST"],["ACK"],["ACK"],
];

let packetCounter = 0;

function generatePacket() {
  packetCounter++;
  const protos = ["TCP","TCP","TCP","UDP","UDP","ICMP"];
  const proto = protos[Math.floor(Math.random() * protos.length)];
  const srcIp = SAMPLE_IPS[Math.floor(Math.random() * SAMPLE_IPS.length)];
  let dstIp;
  do { dstIp = SAMPLE_IPS[Math.floor(Math.random() * SAMPLE_IPS.length)]; }
  while (dstIp === srcIp);
  const dstPort = SAMPLE_PORTS[Math.floor(Math.random() * SAMPLE_PORTS.length)];
  const srcPort = Math.floor(Math.random() * 40000) + 1024;
  const ttl = [64,128,255][Math.floor(Math.random()*3)];
  const size = Math.floor(Math.random() * 1400) + 40;

  let transport = {};
  if (proto === "TCP") {
    transport.flags = TCP_FLAG_COMBOS[Math.floor(Math.random()*TCP_FLAG_COMBOS.length)];
    transport.seq = Math.floor(Math.random() * 2**31);
    transport.ack = Math.floor(Math.random() * 2**31);
    transport.window = [8192,16384,32768,65535][Math.floor(Math.random()*4)];
    transport.srcPort = srcPort;
    transport.dstPort = dstPort;
  } else if (proto === "UDP") {
    transport.srcPort = srcPort;
    transport.dstPort = dstPort;
    transport.length = size;
  } else {
    const typeOpts = [0,8,3,11];
    transport.icmpType = typeOpts[Math.floor(Math.random()*typeOpts.length)];
    transport.icmpName = ICMP_TYPES[transport.icmpType] || `Type-${transport.icmpType}`;
    transport.code = 0;
  }

  const payload = Array.from({length: Math.floor(Math.random()*32)},
    () => Math.floor(Math.random()*128));

  return {
    id: packetCounter,
    timestamp: new Date(),
    proto, srcIp, dstIp, ttl, size, transport, payload,
    service: WELL_KNOWN_PORTS[dstPort] || WELL_KNOWN_PORTS[srcPort] || "Unknown",
  };
}

// ── Utilities ──────────────────────────────────────────────────────────────────
function humanBytes(n) {
  if (n < 1024) return `${n}B`;
  if (n < 1048576) return `${(n/1024).toFixed(1)}KB`;
  return `${(n/1048576).toFixed(2)}MB`;
}
function hexByte(n) { return n.toString(16).padStart(2,"0"); }
function formatTime(d) {
  return d.toTimeString().slice(0,8) + "." + String(d.getMilliseconds()).padStart(3,"0");
}

// ── Sub-components ─────────────────────────────────────────────────────────────
function ProtoTag({ proto }) {
  const s = PROTO_STYLE[proto] || PROTO_STYLE.OTHER;
  return (
    <span style={{
      background: s.bg, color: s.fg,
      border: `1px solid ${s.border}`,
      borderRadius: 4, padding: "1px 7px",
      fontSize: 11, fontWeight: 700,
      fontFamily: "monospace", letterSpacing: 1,
    }}>{proto}</span>
  );
}

function FlagBadge({ flag }) {
  const color = FLAG_COLORS[flag] || "#888";
  return (
    <span style={{
      color, border: `1px solid ${color}`,
      borderRadius: 3, padding: "0 5px",
      fontSize: 10, fontWeight: 700,
      fontFamily: "monospace", marginRight: 3,
    }}>{flag}</span>
  );
}

function MiniBar({ value, max, color = PALETTE.accent }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
      <div style={{
        flex: 1, height: 6, background: PALETTE.border,
        borderRadius: 3, overflow: "hidden",
      }}>
        <div style={{
          width: `${pct}%`, height:"100%",
          background: color, borderRadius: 3,
          transition: "width 0.4s ease",
        }} />
      </div>
      <span style={{ fontSize:11, color: PALETTE.dim, minWidth:30, textAlign:"right" }}>
        {pct}%
      </span>
    </div>
  );
}

function HexDump({ payload }) {
  if (!payload || payload.length === 0) {
    return <span style={{ color: PALETTE.dim, fontSize: 11 }}>— no payload —</span>;
  }
  const rows = [];
  for (let i = 0; i < Math.min(payload.length, 48); i += 16) {
    const chunk = payload.slice(i, i+16);
    const hex = chunk.map(hexByte).join(" ");
    const asc = chunk.map(b => (b >= 32 && b < 127) ? String.fromCharCode(b) : ".").join("");
    rows.push(
      <div key={i} style={{ display:"flex", gap:16, fontSize:11, lineHeight:"18px" }}>
        <span style={{ color: PALETTE.dim, minWidth:32 }}>{i.toString(16).padStart(4,"0")}</span>
        <span style={{ color: PALETTE.accent, fontFamily:"monospace", minWidth:140 }}>{hex}</span>
        <span style={{ color: PALETTE.text, fontFamily:"monospace" }}>{asc}</span>
      </div>
    );
  }
  if (payload.length > 48) {
    rows.push(
      <div key="more" style={{ color: PALETTE.dim, fontSize:11 }}>
        … {payload.length - 48} more bytes
      </div>
    );
  }
  return <div>{rows}</div>;
}

function PacketRow({ pkt, selected, onClick }) {
  const isNew = Date.now() - pkt.timestamp.getTime() < 600;
  return (
    <div
      onClick={onClick}
      style={{
        display: "grid",
        gridTemplateColumns: "48px 90px 80px 130px 20px 130px 80px 60px",
        gap: "0 8px",
        padding: "5px 12px",
        background: selected ? "#0d1e38"
                  : isNew    ? "#0c1a30"
                  : "transparent",
        borderLeft: selected
          ? `2px solid ${PALETTE.accent}`
          : "2px solid transparent",
        cursor: "pointer",
        alignItems: "center",
        fontSize: 12,
        fontFamily: "monospace",
        transition: "background 0.15s",
        borderBottom: `1px solid ${PALETTE.border}22`,
      }}
    >
      <span style={{ color: PALETTE.dim }}>#{pkt.id}</span>
      <span style={{ color: PALETTE.dim }}>{formatTime(pkt.timestamp)}</span>
      <span><ProtoTag proto={pkt.proto} /></span>
      <span style={{ color: PALETTE.warn }}>{pkt.srcIp}</span>
      <span style={{ color: PALETTE.dim }}>→</span>
      <span style={{ color: PALETTE.accent }}>{pkt.dstIp}</span>
      <span style={{ color: PALETTE.accent2 }}>{pkt.service}</span>
      <span style={{ color: PALETTE.dim, textAlign:"right" }}>{humanBytes(pkt.size)}</span>
    </div>
  );
}

function PacketDetail({ pkt }) {
  if (!pkt) {
    return (
      <div style={{
        flex:1, display:"flex", alignItems:"center", justifyContent:"center",
        color: PALETTE.dim, fontSize: 13, fontFamily:"monospace",
      }}>
        ← Select a packet to inspect
      </div>
    );
  }
  const t = pkt.transport;
  const portSvc = (p) => WELL_KNOWN_PORTS[p] ? `${p} (${WELL_KNOWN_PORTS[p]})` : `${p}`;

  const Section = ({ title, children }) => (
    <div style={{
      border: `1px solid ${PALETTE.border}`,
      borderRadius: 6, marginBottom: 10,
      overflow: "hidden",
    }}>
      <div style={{
        background: PALETTE.border, padding: "5px 12px",
        fontSize: 11, fontWeight: 700, color: PALETTE.accent,
        letterSpacing: 1, textTransform: "uppercase",
      }}>{title}</div>
      <div style={{ padding: "10px 12px" }}>{children}</div>
    </div>
  );

  const Row = ({ label, value, color }) => (
    <div style={{ display:"flex", gap:12, marginBottom:5, fontSize:12, fontFamily:"monospace" }}>
      <span style={{ color: PALETTE.dim, minWidth:100 }}>{label}</span>
      <span style={{ color: color || PALETTE.text }}>{value}</span>
    </div>
  );

  return (
    <div style={{ padding:"12px", overflow:"auto", height:"100%" }}>
      <div style={{
        fontSize:13, fontWeight:700, marginBottom:12,
        color: PALETTE.accent, fontFamily:"monospace",
        display:"flex", alignItems:"center", gap:10,
      }}>
        <ProtoTag proto={pkt.proto} />
        Packet #{pkt.id}  ·  {formatTime(pkt.timestamp)}
      </div>

      <Section title="▸ IPv4 Network Layer">
        <Row label="Source IP"      value={pkt.srcIp}        color={PALETTE.warn} />
        <Row label="Destination IP" value={pkt.dstIp}        color={PALETTE.accent} />
        <Row label="TTL"            value={pkt.ttl}           color={PALETTE.accent2} />
        <Row label="Total Length"   value={`${pkt.size} bytes`} />
        <Row label="Protocol"       value={pkt.proto} />
        <Row label="Service"        value={pkt.service}       color={PALETTE.accent2} />
      </Section>

      {pkt.proto === "TCP" && (
        <Section title="▸ TCP Transport Layer">
          <Row label="Source Port"  value={portSvc(t.srcPort)} color={PALETTE.warn} />
          <Row label="Dest Port"    value={portSvc(t.dstPort)} color={PALETTE.accent} />
          <Row label="Seq Number"   value={t.seq.toLocaleString()} />
          <Row label="Ack Number"   value={t.ack.toLocaleString()} />
          <Row label="Window"       value={t.window.toLocaleString() + " bytes"} />
          <div style={{ display:"flex", gap:8, marginTop:8, flexWrap:"wrap" }}>
            {t.flags.map(f => <FlagBadge key={f} flag={f} />)}
          </div>
          <div style={{
            marginTop:10, fontSize:11, color: PALETTE.dim,
            borderTop:`1px solid ${PALETTE.border}`, paddingTop:8,
          }}>
            {t.flags.includes("SYN") && !t.flags.includes("ACK") &&
              "→ SYN: initiating new connection (3-way handshake step 1)"}
            {t.flags.includes("SYN") && t.flags.includes("ACK") &&
              "→ SYN+ACK: server accepting connection (step 2)"}
            {t.flags.includes("ACK") && !t.flags.includes("SYN") && !t.flags.includes("FIN") &&
              !t.flags.includes("RST") && !t.flags.includes("PSH") &&
              "→ ACK: acknowledging received data"}
            {t.flags.includes("PSH") &&
              "→ PSH: push data to application immediately"}
            {t.flags.includes("FIN") &&
              "→ FIN: graceful connection teardown"}
            {t.flags.includes("RST") &&
              "→ RST: abrupt connection reset"}
          </div>
        </Section>
      )}

      {pkt.proto === "UDP" && (
        <Section title="▸ UDP Transport Layer">
          <Row label="Source Port"   value={portSvc(t.srcPort)} color={PALETTE.warn} />
          <Row label="Dest Port"     value={portSvc(t.dstPort)} color={PALETTE.accent} />
          <Row label="Length"        value={`${t.length} bytes`} />
          <div style={{ fontSize:11, color: PALETTE.dim, marginTop:6 }}>
            UDP is connectionless — no handshake, no guaranteed delivery.
            Ideal for DNS, video streaming, gaming.
          </div>
        </Section>
      )}

      {pkt.proto === "ICMP" && (
        <Section title="▸ ICMP (Ping/Diagnostic)">
          <Row label="Type"  value={`${t.icmpType} — ${t.icmpName}`} color={PALETTE.accent} />
          <Row label="Code"  value={t.code} />
          {t.icmpType === 8 && <div style={{fontSize:11,color:PALETTE.dim,marginTop:6}}>→ Echo Request (ping sent)</div>}
          {t.icmpType === 0 && <div style={{fontSize:11,color:PALETTE.dim,marginTop:6}}>→ Echo Reply (pong received)</div>}
          {t.icmpType === 3 && <div style={{fontSize:11,color:PALETTE.dim,marginTop:6}}>→ Destination Unreachable — routing problem</div>}
          {t.icmpType === 11 && <div style={{fontSize:11,color:PALETTE.dim,marginTop:6}}>→ Time Exceeded — TTL reached 0 (traceroute)</div>}
        </Section>
      )}

      <Section title="▸ Payload (Hex + ASCII)">
        <HexDump payload={pkt.payload} />
      </Section>
    </div>
  );
}

function StatsPanel({ packets }) {
  const protoCount = {};
  const srcCount = {};
  const dstCount = {};
  const svcCount = {};
  let totalBytes = 0;
  const flagCount = {};

  for (const p of packets) {
    protoCount[p.proto] = (protoCount[p.proto] || 0) + 1;
    srcCount[p.srcIp]   = (srcCount[p.srcIp]   || 0) + 1;
    dstCount[p.dstIp]   = (dstCount[p.dstIp]   || 0) + 1;
    svcCount[p.service] = (svcCount[p.service]  || 0) + 1;
    totalBytes += p.size;
    if (p.proto === "TCP" && p.transport.flags) {
      for (const f of p.transport.flags)
        flagCount[f] = (flagCount[f] || 0) + 1;
    }
  }

  const top = (obj, n=5) => Object.entries(obj)
    .sort((a,b)=>b[1]-a[1]).slice(0,n);

  const maxProto = Math.max(...Object.values(protoCount), 1);
  const maxSrc   = Math.max(...Object.values(srcCount), 1);
  const maxDst   = Math.max(...Object.values(dstCount), 1);
  const maxSvc   = Math.max(...Object.values(svcCount), 1);

  const Section = ({ title, children }) => (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize:10, color: PALETTE.accent, letterSpacing:2, marginBottom:8,
                    textTransform:"uppercase", fontWeight:700 }}>{title}</div>
      {children}
    </div>
  );

  const Stat = ({ label, value, color }) => (
    <div style={{ display:"flex", justifyContent:"space-between",
                  marginBottom:5, fontSize:12, fontFamily:"monospace" }}>
      <span style={{ color: PALETTE.dim }}>{label}</span>
      <span style={{ color: color || PALETTE.text, fontWeight:700 }}>{value}</span>
    </div>
  );

  return (
    <div style={{ padding:"12px 16px", overflowY:"auto", height:"100%" }}>
      <Section title="Overview">
        <Stat label="Total Packets" value={packets.length.toLocaleString()} color={PALETTE.accent} />
        <Stat label="Total Bytes"   value={humanBytes(totalBytes)} color={PALETTE.accent2} />
      </Section>

      <Section title="Protocol Mix">
        {top(protoCount).map(([proto, cnt]) => (
          <div key={proto} style={{ marginBottom:8 }}>
            <div style={{ display:"flex", justifyContent:"space-between",
                          fontSize:12, fontFamily:"monospace", marginBottom:3 }}>
              <span style={{ color: (PROTO_STYLE[proto]||PROTO_STYLE.OTHER).fg }}>{proto}</span>
              <span style={{ color: PALETTE.dim }}>{cnt}</span>
            </div>
            <MiniBar value={cnt} max={maxProto}
                     color={(PROTO_STYLE[proto]||PROTO_STYLE.OTHER).fg} />
          </div>
        ))}
      </Section>

      <Section title="Top Sources">
        {top(srcCount).map(([ip, cnt]) => (
          <div key={ip} style={{ marginBottom:8 }}>
            <div style={{ display:"flex", justifyContent:"space-between",
                          fontSize:11, fontFamily:"monospace", marginBottom:3 }}>
              <span style={{ color: PALETTE.warn }}>{ip}</span>
              <span style={{ color: PALETTE.dim }}>{cnt}</span>
            </div>
            <MiniBar value={cnt} max={maxSrc} color={PALETTE.warn} />
          </div>
        ))}
      </Section>

      <Section title="Top Destinations">
        {top(dstCount).map(([ip, cnt]) => (
          <div key={ip} style={{ marginBottom:8 }}>
            <div style={{ display:"flex", justifyContent:"space-between",
                          fontSize:11, fontFamily:"monospace", marginBottom:3 }}>
              <span style={{ color: PALETTE.accent }}>{ip}</span>
              <span style={{ color: PALETTE.dim }}>{cnt}</span>
            </div>
            <MiniBar value={cnt} max={maxDst} color={PALETTE.accent} />
          </div>
        ))}
      </Section>

      <Section title="Services">
        {top(svcCount).map(([svc, cnt]) => (
          <div key={svc} style={{ marginBottom:8 }}>
            <div style={{ display:"flex", justifyContent:"space-between",
                          fontSize:11, fontFamily:"monospace", marginBottom:3 }}>
              <span style={{ color: PALETTE.accent2 }}>{svc}</span>
              <span style={{ color: PALETTE.dim }}>{cnt}</span>
            </div>
            <MiniBar value={cnt} max={maxSvc} color={PALETTE.accent2} />
          </div>
        ))}
      </Section>

      {Object.keys(flagCount).length > 0 && (
        <Section title="TCP Flags">
          {Object.entries(flagCount).sort((a,b)=>b[1]-a[1]).map(([f,cnt]) => (
            <div key={f} style={{ display:"flex", justifyContent:"space-between",
                                  fontSize:12, fontFamily:"monospace", marginBottom:5 }}>
              <FlagBadge flag={f} />
              <span style={{ color: PALETTE.dim }}>{cnt}</span>
            </div>
          ))}
        </Section>
      )}
    </div>
  );
}

function EducationPanel() {
  const topics = [
    {
      title: "OSI Model — How Data Travels",
      icon: "🔌",
      content: [
        { layer: "L7 Application", desc: "HTTP, DNS, SSH, TLS — what apps send/receive", color: "#ff88aa" },
        { layer: "L4 Transport",   desc: "TCP (reliable) · UDP (fast) — port-to-port", color: "#00ccff" },
        { layer: "L3 Network",     desc: "IPv4/IPv6 — logical addressing, routing", color: "#ffaa00" },
        { layer: "L2 Data Link",   desc: "Ethernet — MAC addressing, frames", color: "#00ff88" },
        { layer: "L1 Physical",    desc: "Bits on wire — cables, Wi-Fi, fiber", color: "#8888ff" },
      ],
    },
    {
      title: "TCP 3-Way Handshake",
      icon: "🤝",
      steps: [
        { from: "Client", to: "Server", msg: "SYN",     desc: "I want to connect", color: "#00ff88" },
        { from: "Server", to: "Client", msg: "SYN+ACK", desc: "OK, I'm ready",      color: "#00aaff" },
        { from: "Client", to: "Server", msg: "ACK",     desc: "Let's go!",           color: "#ffaa00" },
      ],
    },
    {
      title: "Key IPv4 Fields",
      icon: "📦",
      fields: [
        { name: "TTL",      desc: "Hops remaining before discard. Prevents routing loops." },
        { name: "Protocol", desc: "What's inside: 6=TCP, 17=UDP, 1=ICMP" },
        { name: "Checksum", desc: "CRC error detection on the header." },
        { name: "Flags/Frag","desc": "Fragmentation control for large packets." },
        { name: "DSCP",     desc: "Quality of Service / traffic priority marking." },
      ],
    },
    {
      title: "Why TTL Matters",
      icon: "⏱️",
      text: "Every router decrements TTL by 1. When it hits 0, the packet is dropped and an ICMP 'Time Exceeded' is sent back. Traceroute exploits this by sending packets with TTL=1,2,3… to map the path hop-by-hop.",
    },
    {
      title: "TCP vs UDP",
      icon: "⚖️",
      compare: [
        { tcp: "Connection-oriented",  udp: "Connectionless" },
        { tcp: "Guaranteed delivery",  udp: "Best-effort" },
        { tcp: "Flow & congestion control", udp: "No flow control" },
        { tcp: "Ordered bytes",        udp: "Out-of-order OK" },
        { tcp: "HTTP, SSH, FTP",       udp: "DNS, Video, Gaming" },
      ],
    },
  ];

  const [open, setOpen] = useState(0);

  return (
    <div style={{ padding:"12px 16px", overflowY:"auto", height:"100%" }}>
      <div style={{ fontSize:13, fontWeight:700, color: PALETTE.accent,
                    marginBottom:14, letterSpacing:1 }}>
        📚 PROTOCOL REFERENCE
      </div>
      {topics.map((t, i) => (
        <div key={i} style={{ marginBottom:8 }}>
          <div
            onClick={() => setOpen(open === i ? -1 : i)}
            style={{
              background: open === i ? PALETTE.border : PALETTE.panel,
              border: `1px solid ${open === i ? PALETTE.accent : PALETTE.border}`,
              borderRadius: 6, padding:"10px 14px",
              cursor:"pointer", fontSize:12,
              color: open === i ? PALETTE.accent : PALETTE.text,
              fontWeight: 700,
              display:"flex", justifyContent:"space-between",
              transition:"all 0.2s",
            }}
          >
            <span>{t.icon} {t.title}</span>
            <span style={{ color: PALETTE.dim }}>{open === i ? "▲" : "▼"}</span>
          </div>

          {open === i && (
            <div style={{
              background: "#0a0f1e",
              border: `1px solid ${PALETTE.border}`,
              borderTop: "none",
              borderRadius: "0 0 6px 6px",
              padding: "12px 14px",
              fontSize: 12,
            }}>
              {t.content && t.content.map((c, j) => (
                <div key={j} style={{
                  display:"flex", gap:12, alignItems:"center",
                  marginBottom:8, fontFamily:"monospace",
                }}>
                  <span style={{
                    color: c.color, minWidth:120, fontWeight:700,
                  }}>{c.layer}</span>
                  <span style={{ color: PALETTE.dim }}>{c.desc}</span>
                </div>
              ))}
              {t.steps && t.steps.map((s, j) => (
                <div key={j} style={{
                  display:"flex", gap:10, alignItems:"center",
                  marginBottom:8, fontFamily:"monospace",
                }}>
                  <span style={{ color: PALETTE.dim, minWidth:50 }}>{s.from}</span>
                  <span style={{ color: s.color, fontWeight:700, minWidth:70 }}>{s.msg} →</span>
                  <span style={{ color: PALETTE.dim, minWidth:50 }}>{s.to}</span>
                  <span style={{ color: PALETTE.text, fontSize:11 }}>{s.desc}</span>
                </div>
              ))}
              {t.fields && t.fields.map((f, j) => (
                <div key={j} style={{ marginBottom:8, fontFamily:"monospace" }}>
                  <span style={{ color: PALETTE.accent, fontWeight:700, marginRight:10 }}>{f.name}</span>
                  <span style={{ color: PALETTE.dim, fontSize:11 }}>{f.desc}</span>
                </div>
              ))}
              {t.text && <p style={{ color: PALETTE.dim, lineHeight:1.6, margin:0 }}>{t.text}</p>}
              {t.compare && (
                <table style={{ width:"100%", borderCollapse:"collapse" }}>
                  <thead>
                    <tr>
                      <th style={{ color: PALETTE.accent, textAlign:"left", padding:"4px 8px", borderBottom:`1px solid ${PALETTE.border}` }}>TCP</th>
                      <th style={{ color: PALETTE.accent2, textAlign:"left", padding:"4px 8px", borderBottom:`1px solid ${PALETTE.border}` }}>UDP</th>
                    </tr>
                  </thead>
                  <tbody>
                    {t.compare.map((row, j) => (
                      <tr key={j}>
                        <td style={{ color: PALETTE.text, padding:"5px 8px", fontSize:11, borderBottom:`1px solid ${PALETTE.border}22` }}>{row.tcp}</td>
                        <td style={{ color: PALETTE.dim, padding:"5px 8px", fontSize:11, borderBottom:`1px solid ${PALETTE.border}22` }}>{row.udp}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────────
export default function App() {
  const [packets, setPackets] = useState([]);
  const [selected, setSelected] = useState(null);
  const [running, setRunning] = useState(false);
  const [filter, setFilter] = useState("ALL");
  const [tab, setTab] = useState("capture"); // capture | stats | learn
  const [speed, setSpeed] = useState(800);
  const intervalRef = useRef(null);
  const listRef = useRef(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [search, setSearch] = useState("");

  const addPacket = useCallback(() => {
    setPackets(prev => {
      const pkt = generatePacket();
      const next = [...prev, pkt];
      return next.slice(-500); // cap at 500
    });
  }, []);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(addPacket, speed);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [running, speed, addPacket]);

  useEffect(() => {
    if (autoScroll && listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [packets, autoScroll]);

  const filtered = packets.filter(p => {
    if (filter !== "ALL" && p.proto !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return p.srcIp.includes(q) || p.dstIp.includes(q) ||
             p.service.toLowerCase().includes(q) ||
             p.proto.toLowerCase().includes(q);
    }
    return true;
  });

  const TABS = ["capture","stats","learn"];

  return (
    <div style={{
      background: PALETTE.bg,
      color: PALETTE.text,
      minHeight: "100vh",
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
      display: "flex",
      flexDirection: "column",
    }}>
      {/* ── Top Bar ── */}
      <div style={{
        background: PALETTE.panel,
        borderBottom: `1px solid ${PALETTE.border}`,
        padding: "10px 20px",
        display: "flex",
        alignItems: "center",
        gap: 16,
        flexWrap: "wrap",
      }}>
        {/* Logo */}
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <div style={{ fontSize:18 }}>📡</div>
          <div>
            <div style={{ fontSize:14, fontWeight:900, color: PALETTE.accent,
                          letterSpacing:2, lineHeight:1 }}>PKTSNIFF</div>
            <div style={{ fontSize:9, color: PALETTE.dim, letterSpacing:3 }}>PACKET ANALYZER</div>
          </div>
        </div>

        <div style={{ width:1, height:32, background: PALETTE.border }} />

        {/* Controls */}
        <button
          onClick={() => setRunning(r => !r)}
          style={{
            background: running ? "#1a0000" : "#001a00",
            border: `1px solid ${running ? PALETTE.danger : PALETTE.accent2}`,
            color: running ? PALETTE.danger : PALETTE.accent2,
            padding: "6px 16px", borderRadius: 5,
            cursor:"pointer", fontSize:12, fontWeight:700,
            letterSpacing: 1,
          }}
        >
          {running ? "⏹ STOP" : "▶ START"}
        </button>

        <button
          onClick={() => { setPackets([]); setSelected(null); packetCounter = 0; }}
          style={{
            background: "transparent",
            border: `1px solid ${PALETTE.muted}`,
            color: PALETTE.dim,
            padding: "6px 12px", borderRadius: 5,
            cursor:"pointer", fontSize:12,
          }}
        >
          ⟳ Clear
        </button>

        {/* Speed */}
        <div style={{ display:"flex", alignItems:"center", gap:8, fontSize:11 }}>
          <span style={{ color: PALETTE.dim }}>Speed</span>
          {[["Slow",1400],["Med",800],["Fast",300]].map(([l,v]) => (
            <button key={l} onClick={() => setSpeed(v)} style={{
              background: speed === v ? PALETTE.border : "transparent",
              border: `1px solid ${speed === v ? PALETTE.accent : PALETTE.muted}`,
              color: speed === v ? PALETTE.accent : PALETTE.dim,
              padding: "3px 10px", borderRadius:4,
              cursor:"pointer", fontSize:11,
            }}>{l}</button>
          ))}
        </div>

        {/* Filter */}
        <div style={{ display:"flex", alignItems:"center", gap:8, fontSize:11 }}>
          <span style={{ color: PALETTE.dim }}>Proto</span>
          {["ALL","TCP","UDP","ICMP"].map(p => (
            <button key={p} onClick={() => setFilter(p)} style={{
              background: filter === p ? (PROTO_STYLE[p]?.bg || PALETTE.border) : "transparent",
              border: `1px solid ${filter === p ? (PROTO_STYLE[p]?.border || PALETTE.accent) : PALETTE.muted}`,
              color: filter === p ? (PROTO_STYLE[p]?.fg || PALETTE.accent) : PALETTE.dim,
              padding: "3px 10px", borderRadius:4,
              cursor:"pointer", fontSize:11, fontWeight: filter === p ? 700 : 400,
            }}>{p}</button>
          ))}
        </div>

        {/* Search */}
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search IP / service…"
          style={{
            background: PALETTE.panel, border: `1px solid ${PALETTE.border}`,
            color: PALETTE.text, padding:"5px 10px", borderRadius:5,
            fontSize:11, outline:"none", width:180,
          }}
        />

        {/* Live counter */}
        <div style={{ marginLeft:"auto", textAlign:"right" }}>
          <div style={{ fontSize:18, fontWeight:900, color: PALETTE.accent,
                        lineHeight:1 }}>{packets.length}</div>
          <div style={{ fontSize:9, color: PALETTE.dim }}>PACKETS</div>
        </div>

        {/* Running indicator */}
        {running && (
          <div style={{ display:"flex", alignItems:"center", gap:6 }}>
            <div style={{
              width:8, height:8, borderRadius:"50%",
              background: PALETTE.accent2,
              boxShadow: `0 0 8px ${PALETTE.accent2}`,
              animation: "pulse 1s infinite",
            }} />
            <span style={{ fontSize:10, color: PALETTE.accent2 }}>LIVE</span>
          </div>
        )}
      </div>

      {/* ── Tabs ── */}
      <div style={{
        background: PALETTE.panel,
        borderBottom: `1px solid ${PALETTE.border}`,
        display: "flex",
        padding: "0 20px",
        gap: 0,
      }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            background: "transparent",
            border: "none",
            borderBottom: `2px solid ${tab === t ? PALETTE.accent : "transparent"}`,
            color: tab === t ? PALETTE.accent : PALETTE.dim,
            padding: "10px 20px",
            cursor: "pointer",
            fontSize: 11,
            fontWeight: 700,
            letterSpacing: 1,
            textTransform: "uppercase",
            fontFamily: "inherit",
            transition: "all 0.2s",
          }}>
            { t === "capture" ? "📡 Capture"
            : t === "stats"   ? "📊 Statistics"
            :                   "📚 Learn" }
          </button>
        ))}
      </div>

      {/* ── Body ── */}
      <div style={{ flex:1, display:"flex", overflow:"hidden", minHeight:0 }}>

        {/* CAPTURE TAB */}
        {tab === "capture" && (
          <>
            {/* Packet List */}
            <div style={{
              width: "55%", display:"flex", flexDirection:"column",
              borderRight: `1px solid ${PALETTE.border}`,
            }}>
              {/* Column headers */}
              <div style={{
                display:"grid",
                gridTemplateColumns:"48px 90px 80px 130px 20px 130px 80px 60px",
                gap:"0 8px", padding:"5px 12px",
                background: PALETTE.panel,
                borderBottom: `1px solid ${PALETTE.border}`,
                fontSize:10, color: PALETTE.dim, letterSpacing:1,
                textTransform:"uppercase",
              }}>
                <span>#</span><span>Time</span><span>Proto</span>
                <span>Source</span><span></span><span>Dest</span>
                <span>Service</span><span>Size</span>
              </div>

              <div ref={listRef} style={{ flex:1, overflowY:"auto" }}
                onScroll={e => {
                  const el = e.target;
                  const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
                  setAutoScroll(atBottom);
                }}
              >
                {filtered.length === 0 ? (
                  <div style={{
                    flex:1, display:"flex", alignItems:"center", justifyContent:"center",
                    color: PALETTE.dim, fontSize:13, padding:40, textAlign:"center",
                  }}>
                    {running ? "Capturing packets…" : "Press ▶ START to begin capture"}
                  </div>
                ) : filtered.map(pkt => (
                  <PacketRow
                    key={pkt.id}
                    pkt={pkt}
                    selected={selected?.id === pkt.id}
                    onClick={() => setSelected(pkt)}
                  />
                ))}
              </div>

              <div style={{
                borderTop: `1px solid ${PALETTE.border}`,
                padding: "6px 12px",
                fontSize: 10, color: PALETTE.dim,
                display:"flex", justifyContent:"space-between",
              }}>
                <span>{filtered.length} / {packets.length} packets</span>
                <span
                  onClick={() => setAutoScroll(a => !a)}
                  style={{ cursor:"pointer", color: autoScroll ? PALETTE.accent2 : PALETTE.dim }}
                >
                  {autoScroll ? "↓ Auto-scroll ON" : "↓ Auto-scroll OFF"}
                </span>
              </div>
            </div>

            {/* Detail Panel */}
            <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
              <div style={{
                background: PALETTE.panel,
                borderBottom: `1px solid ${PALETTE.border}`,
                padding: "6px 12px",
                fontSize: 10, color: PALETTE.dim, letterSpacing: 1,
                textTransform: "uppercase",
              }}>
                Packet Inspector
              </div>
              <div style={{ flex:1, overflow:"auto" }}>
                <PacketDetail pkt={selected} />
              </div>
            </div>
          </>
        )}

        {/* STATS TAB */}
        {tab === "stats" && (
          <div style={{ flex:1, overflow:"hidden" }}>
            <StatsPanel packets={packets} />
          </div>
        )}

        {/* LEARN TAB */}
        {tab === "learn" && (
          <div style={{ flex:1, overflow:"hidden" }}>
            <EducationPanel />
          </div>
        )}
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50%       { opacity: 0.5; transform: scale(1.3); }
        }
        ::-webkit-scrollbar { width:6px; }
        ::-webkit-scrollbar-track { background: ${PALETTE.bg}; }
        ::-webkit-scrollbar-thumb { background: ${PALETTE.border}; border-radius:3px; }
        ::-webkit-scrollbar-thumb:hover { background: ${PALETTE.muted}; }
        * { box-sizing: border-box; }
      `}</style>
    </div>
  );
}
