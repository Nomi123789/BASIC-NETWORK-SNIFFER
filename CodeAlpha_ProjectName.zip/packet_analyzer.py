#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║           NETWORK PACKET ANALYZER  v1.0                      ║
║       Capture · Decode · Analyze · Learn                     ║
╚══════════════════════════════════════════════════════════════╝

A comprehensive network packet analyzer using Python's `socket`
library (no external dependencies). Captures raw packets, decodes
headers, and displays human-readable network intelligence.

Usage:
  sudo python3 packet_analyzer.py                  # Capture live packets
  sudo python3 packet_analyzer.py --count 20       # Stop after 20 packets
  sudo python3 packet_analyzer.py --filter tcp     # Show only TCP packets
  sudo python3 packet_analyzer.py --filter udp     # Show only UDP packets
  sudo python3 packet_analyzer.py --filter icmp    # Show only ICMP packets
  sudo python3 packet_analyzer.py --stats-only     # Summary stats only
  python3  packet_analyzer.py --demo               # Demo mode (no root needed)

NOTE: Live capture requires root/admin privileges (sudo on Linux/macOS).
      Use --demo to explore all features without elevated permissions.
"""

import socket
import struct
import sys
import time
import argparse
import textwrap
import random
import os
from datetime import datetime
from collections import defaultdict


# ─────────────────────────────────────────────
#  ANSI COLOR PALETTE
# ─────────────────────────────────────────────
class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"

    # Foregrounds
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    GRAY    = "\033[90m"

    # Backgrounds
    BG_RED  = "\033[41m"
    BG_BLUE = "\033[44m"
    BG_DARK = "\033[40m"

    @staticmethod
    def rgb(r, g, b, text):
        return f"\033[38;2;{r};{g};{b}m{text}\033[0m"


# ─────────────────────────────────────────────
#  PROTOCOL MAPS
# ─────────────────────────────────────────────
PROTO_MAP = {
    1:   ("ICMP", C.MAGENTA),
    6:   ("TCP",  C.CYAN),
    17:  ("UDP",  C.GREEN),
    41:  ("IPv6", C.YELLOW),
    47:  ("GRE",  C.GRAY),
    50:  ("ESP",  C.RED),
    58:  ("ICMPv6", C.MAGENTA),
    89:  ("OSPF", C.YELLOW),
    132: ("SCTP", C.BLUE),
}

PORT_SERVICES = {
    20: "FTP-Data", 21: "FTP", 22: "SSH", 23: "Telnet",
    25: "SMTP", 53: "DNS", 67: "DHCP-S", 68: "DHCP-C",
    69: "TFTP", 80: "HTTP", 110: "POP3", 119: "NNTP",
    123: "NTP", 143: "IMAP", 161: "SNMP", 194: "IRC",
    389: "LDAP", 443: "HTTPS", 465: "SMTPS", 514: "Syslog",
    587: "SMTP-Sub", 636: "LDAPS", 993: "IMAPS", 995: "POP3S",
    1080: "SOCKS", 1194: "OpenVPN", 1433: "MSSQL", 1521: "Oracle",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 5900: "VNC",
    6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 27017: "MongoDB",
}

ICMP_TYPES = {
    0: "Echo Reply", 3: "Dest Unreachable", 4: "Source Quench",
    5: "Redirect", 8: "Echo Request", 9: "Router Advert",
    10: "Router Solicit", 11: "Time Exceeded", 12: "Param Problem",
    13: "Timestamp", 14: "Timestamp Reply",
}

TCP_FLAGS = {
    0x01: ("FIN", C.YELLOW),
    0x02: ("SYN", C.GREEN),
    0x04: ("RST", C.RED),
    0x08: ("PSH", C.CYAN),
    0x10: ("ACK", C.BLUE),
    0x20: ("URG", C.MAGENTA),
    0x40: ("ECE", C.GRAY),
    0x80: ("CWR", C.GRAY),
}


# ─────────────────────────────────────────────
#  PACKET STATISTICS TRACKER
# ─────────────────────────────────────────────
class Stats:
    def __init__(self):
        self.total        = 0
        self.by_proto     = defaultdict(int)
        self.by_src_ip    = defaultdict(int)
        self.by_dst_ip    = defaultdict(int)
        self.by_port      = defaultdict(int)
        self.total_bytes  = 0
        self.start_time   = time.time()
        self.tcp_flags    = defaultdict(int)

    def record(self, proto_name, src_ip, dst_ip, size,
               src_port=None, dst_port=None, flags=None):
        self.total        += 1
        self.total_bytes  += size
        self.by_proto[proto_name] += 1
        self.by_src_ip[src_ip]    += 1
        self.by_dst_ip[dst_ip]    += 1
        if src_port:
            svc = PORT_SERVICES.get(src_port, str(src_port))
            self.by_port[svc] += 1
        if dst_port:
            svc = PORT_SERVICES.get(dst_port, str(dst_port))
            self.by_port[svc] += 1
        if flags:
            for name, _ in flags:
                self.tcp_flags[name] += 1

    def elapsed(self):
        return time.time() - self.start_time

    def pps(self):
        e = self.elapsed()
        return self.total / e if e > 0 else 0

    def bps(self):
        e = self.elapsed()
        return self.total_bytes / e if e > 0 else 0

    def top(self, d, n=5):
        return sorted(d.items(), key=lambda x: x[1], reverse=True)[:n]


# ─────────────────────────────────────────────
#  PACKET DECODERS
# ─────────────────────────────────────────────
def parse_ethernet(raw):
    """Parse 14-byte Ethernet II frame header."""
    if len(raw) < 14:
        return None
    dst_mac = ":".join(f"{b:02x}" for b in raw[0:6])
    src_mac = ":".join(f"{b:02x}" for b in raw[6:12])
    eth_type = struct.unpack("!H", raw[12:14])[0]
    return {
        "dst_mac":  dst_mac,
        "src_mac":  src_mac,
        "eth_type": eth_type,
        "payload":  raw[14:],
    }

def parse_ipv4(raw):
    """Parse IPv4 header (RFC 791)."""
    if len(raw) < 20:
        return None
    ihl     = (raw[0] & 0x0F) * 4     # header length in bytes
    ttl     = raw[8]
    proto   = raw[9]
    src_ip  = socket.inet_ntoa(raw[12:16])
    dst_ip  = socket.inet_ntoa(raw[16:20])
    total_len = struct.unpack("!H", raw[2:4])[0]
    dscp    = (raw[1] >> 2) & 0x3F
    flags   = (raw[6] >> 5) & 0x07
    frag_off = struct.unpack("!H", raw[6:8])[0] & 0x1FFF
    return {
        "version": 4,
        "ihl":       ihl,
        "ttl":       ttl,
        "proto":     proto,
        "src_ip":    src_ip,
        "dst_ip":    dst_ip,
        "total_len": total_len,
        "dscp":      dscp,
        "flags":     flags,
        "frag_off":  frag_off,
        "payload":   raw[ihl:],
    }

def parse_tcp(raw):
    """Parse TCP header (RFC 793)."""
    if len(raw) < 20:
        return None
    src_port, dst_port = struct.unpack("!HH", raw[0:4])
    seq    = struct.unpack("!I", raw[4:8])[0]
    ack    = struct.unpack("!I", raw[8:12])[0]
    offset = ((raw[12] >> 4) & 0xF) * 4
    flag_byte = raw[13]
    window = struct.unpack("!H", raw[14:16])[0]
    chksum = struct.unpack("!H", raw[16:18])[0]
    urg    = struct.unpack("!H", raw[18:20])[0]

    flags = [(name, col) for bit, (name, col) in TCP_FLAGS.items()
             if flag_byte & bit]

    return {
        "src_port": src_port,
        "dst_port": dst_port,
        "seq":      seq,
        "ack":      ack,
        "offset":   offset,
        "flags":    flags,
        "window":   window,
        "checksum": chksum,
        "urgent":   urg,
        "payload":  raw[offset:],
    }

def parse_udp(raw):
    """Parse UDP header (RFC 768)."""
    if len(raw) < 8:
        return None
    src_port, dst_port = struct.unpack("!HH", raw[0:4])
    length  = struct.unpack("!H", raw[4:6])[0]
    chksum  = struct.unpack("!H", raw[6:8])[0]
    return {
        "src_port": src_port,
        "dst_port": dst_port,
        "length":   length,
        "checksum": chksum,
        "payload":  raw[8:],
    }

def parse_icmp(raw):
    """Parse ICMP header (RFC 792)."""
    if len(raw) < 4:
        return None
    icmp_type = raw[0]
    icmp_code = raw[1]
    chksum    = struct.unpack("!H", raw[2:4])[0]
    type_name = ICMP_TYPES.get(icmp_type, f"Type-{icmp_type}")
    return {
        "type":      icmp_type,
        "code":      icmp_code,
        "type_name": type_name,
        "checksum":  chksum,
        "payload":   raw[4:],
    }

def decode_payload(data, max_bytes=64):
    """Show hex + ASCII side-by-side (Wireshark style)."""
    lines = []
    for i in range(0, min(len(data), max_bytes), 16):
        chunk   = data[i:i+16]
        hex_str = " ".join(f"{b:02x}" for b in chunk)
        asc_str = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        lines.append(f"  {i:04x}  {hex_str:<47}  {asc_str}")
    if len(data) > max_bytes:
        lines.append(f"  ... ({len(data) - max_bytes} more bytes)")
    return "\n".join(lines)

def detect_application(src_port, dst_port, payload):
    """Heuristic application-layer detection."""
    for p in (src_port, dst_port):
        if p in PORT_SERVICES:
            return PORT_SERVICES[p]
    if payload:
        head = payload[:8]
        if head[:4] == b"HTTP":          return "HTTP Response"
        if head[:3] in (b"GET", b"POS",
                        b"PUT", b"DEL"): return "HTTP Request"
        if head[:3] == b"SSH":           return "SSH Handshake"
        if head[:2] == b"\x16\x03":      return "TLS Handshake"
        if len(payload) > 2 and payload[2] == 0xFF: return "DNS"
    return "Unknown"


# ─────────────────────────────────────────────
#  DISPLAY HELPERS
# ─────────────────────────────────────────────
BANNER = f"""
{C.CYAN}{C.BOLD}
  ╔══════════════════════════════════════════════════════════╗
  ║  ██████╗ ██╗  ██╗███████╗████████╗   ██████╗  ██████╗  ║
  ║  ██╔══██╗██║ ██╔╝██╔════╝╚══██╔══╝  ██╔══██╗██╔════╝  ║
  ║  ██████╔╝█████╔╝ █████╗     ██║     ██████╔╝██║       ║
  ║  ██╔═══╝ ██╔═██╗ ██╔══╝     ██║     ██╔═══╝ ██║       ║
  ║  ██║     ██║  ██╗███████╗   ██║     ██║      ╚██████╗  ║
  ║  ╚═╝     ╚═╝  ╚═╝╚══════╝   ╚═╝     ╚═╝       ╚═════╝  ║
  ║          A N A L Y Z E R    v1.0                        ║
  ╚══════════════════════════════════════════════════════════╝
{C.RESET}"""

SEP  = f"{C.GRAY}{'─'*70}{C.RESET}"
SEP2 = f"{C.GRAY}{'═'*70}{C.RESET}"

def fmt_ip(ip):
    return C.YELLOW + ip + C.RESET

def fmt_port(p):
    svc = PORT_SERVICES.get(p, "")
    label = f":{p}"
    if svc:
        label += f"({C.GREEN}{svc}{C.RESET})"
    return C.CYAN + label + C.RESET

def fmt_proto(name, color):
    return f"{color}{C.BOLD}[{name:>5}]{C.RESET}"

def fmt_flags(flags):
    return " ".join(f"{col}{C.BOLD}{name}{C.RESET}"
                    for name, col in flags)

def bar(value, total, width=20, color=C.CYAN):
    filled = int(width * value / total) if total else 0
    return color + "█" * filled + C.GRAY + "░" * (width - filled) + C.RESET

def human_bytes(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def print_packet(pkt_num, ts, ip, transport, proto_name, color,
                 eth=None, show_eth=False, show_payload=False):
    """Pretty-print a single decoded packet."""
    print(SEP)

    # ── Header line ──
    src_port = transport.get("src_port", 0) if transport else 0
    dst_port = transport.get("dst_port", 0) if transport else 0
    app = detect_application(src_port, dst_port,
                             transport.get("payload", b"") if transport else b"")

    ts_str = datetime.fromtimestamp(ts).strftime("%H:%M:%S.%f")[:-3]
    print(f"  {C.GRAY}#{pkt_num:<5}{C.RESET} "
          f"{C.DIM}{ts_str}{C.RESET}  "
          f"{fmt_proto(proto_name, color)}  "
          f"{fmt_ip(ip['src_ip'])}{fmt_port(src_port) if src_port else ''}  "
          f"{C.GRAY}→{C.RESET}  "
          f"{fmt_ip(ip['dst_ip'])}{fmt_port(dst_port) if dst_port else ''}  "
          f"{C.DIM}app={C.RESET}{C.GREEN}{app}{C.RESET}")

    # ── IP layer ──
    print(f"\n  {C.BOLD}IPv4 Layer:{C.RESET}")
    print(f"    TTL={C.YELLOW}{ip['ttl']}{C.RESET}  "
          f"TotalLen={C.CYAN}{ip['total_len']}{C.RESET}B  "
          f"Frag={'Yes' if ip['frag_off'] else 'No'}  "
          f"DSCP={ip['dscp']}")

    # ── Ethernet ──
    if show_eth and eth:
        print(f"  {C.BOLD}Ethernet Layer:{C.RESET}")
        print(f"    src={C.YELLOW}{eth['src_mac']}{C.RESET}  "
              f"dst={C.YELLOW}{eth['dst_mac']}{C.RESET}  "
              f"type=0x{eth['eth_type']:04x}")

    # ── Transport layer ──
    if transport:
        if proto_name == "TCP":
            flags_str = fmt_flags(transport["flags"]) or f"{C.GRAY}none{C.RESET}"
            print(f"\n  {C.BOLD}TCP Layer:{C.RESET}")
            print(f"    Flags={flags_str}")
            print(f"    Seq={C.CYAN}{transport['seq']}{C.RESET}  "
                  f"Ack={C.CYAN}{transport['ack']}{C.RESET}  "
                  f"Window={C.YELLOW}{transport['window']}{C.RESET}  "
                  f"Checksum=0x{transport['checksum']:04x}")

        elif proto_name == "UDP":
            print(f"\n  {C.BOLD}UDP Layer:{C.RESET}")
            print(f"    Length={C.CYAN}{transport['length']}{C.RESET}  "
                  f"Checksum=0x{transport['checksum']:04x}")

        elif proto_name == "ICMP":
            print(f"\n  {C.BOLD}ICMP Layer:{C.RESET}")
            print(f"    Type={C.MAGENTA}{transport['type_name']}{C.RESET} "
                  f"(code={transport['code']})  "
                  f"Checksum=0x{transport['checksum']:04x}")

        # ── Payload ──
        if show_payload and transport.get("payload"):
            pl = transport["payload"]
            print(f"\n  {C.BOLD}Payload{C.RESET} "
                  f"{C.GRAY}({len(pl)} bytes){C.RESET}:")
            print(C.DIM + decode_payload(pl) + C.RESET)

    print()


def print_stats(stats):
    """Print a rich statistics summary."""
    elapsed = stats.elapsed()
    print(f"\n{SEP2}")
    print(f"{C.BOLD}{C.CYAN}  CAPTURE STATISTICS{C.RESET}")
    print(SEP2)

    print(f"\n  {C.BOLD}Overview{C.RESET}")
    print(f"    Packets  : {C.YELLOW}{stats.total:,}{C.RESET}")
    print(f"    Data     : {C.YELLOW}{human_bytes(stats.total_bytes)}{C.RESET}")
    print(f"    Duration : {C.YELLOW}{elapsed:.1f}s{C.RESET}")
    print(f"    Rate     : {C.YELLOW}{stats.pps():.1f} pkt/s  "
          f"{human_bytes(stats.bps())}/s{C.RESET}")

    # Protocol breakdown
    if stats.by_proto:
        print(f"\n  {C.BOLD}Protocol Distribution{C.RESET}")
        total = sum(stats.by_proto.values())
        for proto, count in sorted(stats.by_proto.items(),
                                   key=lambda x: x[1], reverse=True):
            pct = count / total * 100
            _, col = next(((n, c) for n, c in PROTO_MAP.values()
                           if n == proto), (proto, C.WHITE))
            print(f"    {col}{proto:<8}{C.RESET} "
                  f"{bar(count, total, 25, col)} "
                  f"{C.YELLOW}{count:>5}{C.RESET}  {pct:5.1f}%")

    # Top talkers
    if stats.by_src_ip:
        print(f"\n  {C.BOLD}Top Source IPs{C.RESET}")
        for ip, cnt in stats.top(stats.by_src_ip):
            print(f"    {C.YELLOW}{ip:<18}{C.RESET} {cnt:>6} packets")

    # Top destinations
    if stats.by_dst_ip:
        print(f"\n  {C.BOLD}Top Destination IPs{C.RESET}")
        for ip, cnt in stats.top(stats.by_dst_ip):
            print(f"    {C.YELLOW}{ip:<18}{C.RESET} {cnt:>6} packets")

    # Port / service breakdown
    if stats.by_port:
        print(f"\n  {C.BOLD}Top Services (by port){C.RESET}")
        for svc, cnt in stats.top(stats.by_port):
            print(f"    {C.GREEN}{svc:<16}{C.RESET} {cnt:>6} packets")

    # TCP flags
    if stats.tcp_flags:
        print(f"\n  {C.BOLD}TCP Flag Counts{C.RESET}")
        for flag, cnt in sorted(stats.tcp_flags.items(),
                                key=lambda x: x[1], reverse=True):
            _, col = next(((n, c) for _, (n, c) in TCP_FLAGS.items()
                           if n == flag), (flag, C.WHITE))
            print(f"    {col}{flag:<6}{C.RESET} {cnt:>6}")

    print(f"\n{SEP2}\n")


# ─────────────────────────────────────────────
#  DEMO MODE — SYNTHETIC PACKETS
# ─────────────────────────────────────────────
DEMO_IPS   = ["192.168.1.10", "10.0.0.5", "172.16.2.50",
              "8.8.8.8", "1.1.1.1", "93.184.216.34"]
DEMO_PORTS = [80, 443, 53, 22, 3306, 8080, 443, 443, 80, 53]

def gen_demo_packet():
    """Generate a realistic-looking synthetic packet."""
    proto_choice = random.choices(
        [6, 17, 1],
        weights=[60, 30, 10]
    )[0]
    proto_name, color = PROTO_MAP[proto_choice]
    src_ip = random.choice(DEMO_IPS)
    dst_ip = random.choice([ip for ip in DEMO_IPS if ip != src_ip])
    src_port = random.randint(1024, 65535)
    dst_port = random.choice(DEMO_PORTS)

    ip = {
        "src_ip":    src_ip,
        "dst_ip":    dst_ip,
        "ttl":       random.choice([64, 128, 255]),
        "total_len": random.randint(40, 1500),
        "frag_off":  0,
        "dscp":      0,
    }

    transport = None
    if proto_choice == 6:     # TCP
        flag_options = [
            [("SYN", C.GREEN)],
            [("SYN", C.GREEN), ("ACK", C.BLUE)],
            [("ACK", C.BLUE)],
            [("ACK", C.BLUE), ("PSH", C.CYAN)],
            [("FIN", C.YELLOW), ("ACK", C.BLUE)],
            [("RST", C.RED)],
        ]
        transport = {
            "src_port": src_port,
            "dst_port": dst_port,
            "seq":      random.randint(1, 2**32),
            "ack":      random.randint(1, 2**32),
            "flags":    random.choice(flag_options),
            "window":   random.choice([8192, 16384, 65535, 32768]),
            "checksum": random.randint(0, 0xFFFF),
            "urgent":   0,
            "payload":  bytes(random.randint(0, 127)
                              for _ in range(random.randint(0, 80))),
        }
    elif proto_choice == 17:  # UDP
        transport = {
            "src_port": src_port,
            "dst_port": dst_port,
            "length":   random.randint(8, 512),
            "checksum": random.randint(0, 0xFFFF),
            "payload":  bytes(random.randint(0, 127)
                              for _ in range(random.randint(0, 32))),
        }
    else:                     # ICMP
        icmp_type = random.choice([0, 8, 3, 11])
        transport = {
            "type":      icmp_type,
            "code":      0,
            "type_name": ICMP_TYPES.get(icmp_type, f"Type-{icmp_type}"),
            "checksum":  random.randint(0, 0xFFFF),
            "payload":   b"",
        }

    return ip, transport, proto_name, color


# ─────────────────────────────────────────────
#  LIVE CAPTURE
# ─────────────────────────────────────────────
def create_raw_socket():
    """Create a raw socket for packet capture (requires root)."""
    try:
        if sys.platform == "win32":
            s = socket.socket(socket.AF_INET, socket.SOCK_RAW,
                              socket.IPPROTO_IP)
            s.bind((socket.gethostbyname(socket.gethostname()), 0))
            s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            # Windows needs SIO_RCVALL
            import ctypes
            s.ioctl(socket.SIO_RCVALL, socket.RCVALL_ON)
        else:
            # Linux: ETH_P_ALL captures all frames including Ethernet header
            s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW,
                              socket.htons(0x0800))  # IPv4 only
        return s
    except PermissionError:
        print(f"\n{C.RED}[!] Permission denied — run with sudo/root "
              f"for live capture.{C.RESET}")
        print(f"{C.YELLOW}    Try:  sudo python3 {sys.argv[0]}{C.RESET}")
        print(f"{C.CYAN}    Or:   python3 {sys.argv[0]} --demo{C.RESET}\n")
        sys.exit(1)
    except OSError as e:
        print(f"\n{C.RED}[!] Socket error: {e}{C.RESET}")
        print(f"{C.CYAN}    Try:  python3 {sys.argv[0]} --demo{C.RESET}\n")
        sys.exit(1)


def capture_loop(args, stats):
    """Main live-capture loop."""
    sock = create_raw_socket()
    print(f"\n{C.GREEN}[+] Socket opened — capturing packets "
          f"(Ctrl+C to stop){C.RESET}\n")

    pkt_num = 0
    try:
        while True:
            raw_data, _ = sock.recvfrom(65535)
            ts = time.time()

            # On Linux with AF_PACKET we get the Ethernet frame
            eth = parse_ethernet(raw_data)
            if eth and eth["eth_type"] == 0x0800:
                ip_raw = eth["payload"]
            else:
                ip_raw = raw_data   # Windows/fallback

            ip = parse_ipv4(ip_raw)
            if ip is None:
                continue

            proto_name, color = PROTO_MAP.get(ip["proto"],
                                              (f"PROTO-{ip['proto']}", C.GRAY))

            # Protocol filter
            if args.filter and args.filter.upper() != proto_name:
                continue

            transport = None
            if ip["proto"] == 6:
                transport = parse_tcp(ip["payload"])
            elif ip["proto"] == 17:
                transport = parse_udp(ip["payload"])
            elif ip["proto"] == 1:
                transport = parse_icmp(ip["payload"])

            src_port = transport.get("src_port") if transport else None
            dst_port = transport.get("dst_port") if transport else None
            tcp_flags = transport.get("flags") if (transport and ip["proto"]==6) else None

            stats.record(proto_name, ip["src_ip"], ip["dst_ip"],
                         ip["total_len"], src_port, dst_port, tcp_flags)
            pkt_num += 1

            if not args.stats_only:
                print_packet(pkt_num, ts, ip, transport, proto_name, color,
                             eth=eth,
                             show_eth=args.show_eth,
                             show_payload=args.payload)

            if args.count and pkt_num >= args.count:
                break

    except KeyboardInterrupt:
        print(f"\n{C.YELLOW}[*] Capture stopped by user.{C.RESET}")
    finally:
        sock.close()


def demo_loop(args, stats):
    """Demo mode with synthetic packets."""
    print(f"\n{C.CYAN}[DEMO MODE]{C.RESET} Generating synthetic packets "
          f"(no root needed)…\n")
    pkt_num = 0
    count   = args.count or 30
    delay   = 0.4

    try:
        for _ in range(count):
            ip, transport, proto_name, color = gen_demo_packet()

            if args.filter and args.filter.upper() != proto_name:
                continue

            src_port = transport.get("src_port") if transport else None
            dst_port = transport.get("dst_port") if transport else None
            tcp_flags = transport.get("flags") if proto_name=="TCP" else None

            stats.record(proto_name, ip["src_ip"], ip["dst_ip"],
                         ip["total_len"], src_port, dst_port, tcp_flags)
            pkt_num += 1

            if not args.stats_only:
                print_packet(pkt_num, time.time(), ip, transport,
                             proto_name, color,
                             show_payload=args.payload)
            time.sleep(delay)

    except KeyboardInterrupt:
        print(f"\n{C.YELLOW}[*] Demo stopped.{C.RESET}")


# ─────────────────────────────────────────────
#  PROTOCOL EDUCATION
# ─────────────────────────────────────────────
EDUCATION = f"""
{C.CYAN}{C.BOLD}  ╔══ PROTOCOL QUICK REFERENCE ═══════════════════════════════╗{C.RESET}

  {C.BOLD}OSI Layer Model  (what this analyzer covers):{C.RESET}

  Layer 7 {C.GRAY}Application{C.RESET}   HTTP, DNS, SSH, TLS, SMTP, FTP…
  Layer 4 {C.GRAY}Transport  {C.RESET}   {C.CYAN}TCP{C.RESET} (reliable) · {C.GREEN}UDP{C.RESET} (fast)
  Layer 3 {C.GRAY}Network    {C.RESET}   {C.YELLOW}IPv4{C.RESET} — addressing & routing
  Layer 2 {C.GRAY}Data Link  {C.RESET}   Ethernet — MAC addressing
  Layer 1 {C.GRAY}Physical   {C.RESET}   Cables, Wi-Fi, fiber

  {C.BOLD}Key Packet Fields:{C.RESET}

  {C.YELLOW}TTL{C.RESET}       Time-To-Live — decremented each router hop.
            Reaches 0 → packet discarded (prevents loops).
  {C.YELLOW}Seq/Ack{C.RESET}   TCP reliability — every byte is numbered.
  {C.YELLOW}Window{C.RESET}    TCP flow control — receiver advertises buffer size.
  {C.YELLOW}Checksum{C.RESET}  Error detection in IP, TCP, UDP headers.
  {C.YELLOW}Flags{C.RESET}     TCP state machine:
            {C.GREEN}SYN{C.RESET}→ initiate · {C.GREEN}SYN+ACK{C.RESET}→ accept ·
            {C.BLUE}ACK{C.RESET}→ data · {C.YELLOW}FIN{C.RESET}→ close · {C.RED}RST{C.RESET}→ abort

  {C.BOLD}TCP Three-Way Handshake:{C.RESET}
    Client ──SYN──────────────▶ Server
    Client ◀──SYN+ACK────────── Server
    Client ──ACK──────────────▶ Server
    [connection established — data flows]
"""


# ─────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Network Packet Analyzer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent(__doc__))

    parser.add_argument("--count",      type=int,  default=0,
                        help="Stop after N packets (0=unlimited)")
    parser.add_argument("--filter",     type=str,  default="",
                        help="Protocol filter: tcp | udp | icmp")
    parser.add_argument("--payload",    action="store_true",
                        help="Show hex+ASCII payload dump")
    parser.add_argument("--show-eth",   action="store_true",
                        help="Show Ethernet (Layer 2) header")
    parser.add_argument("--stats-only", action="store_true",
                        help="Skip per-packet output, show summary only")
    parser.add_argument("--demo",       action="store_true",
                        help="Run in demo mode (no root needed)")
    parser.add_argument("--education",  action="store_true",
                        help="Print protocol reference and exit")

    args = parser.parse_args()

    print(BANNER)

    if args.education:
        print(EDUCATION)
        return

    print(f"  {C.BOLD}Settings:{C.RESET}")
    print(f"    Mode    : {C.CYAN}{'DEMO' if args.demo else 'LIVE CAPTURE'}{C.RESET}")
    print(f"    Filter  : {C.YELLOW}{args.filter.upper() or 'ALL'}{C.RESET}")
    print(f"    Payload : {C.YELLOW}{'yes' if args.payload else 'no'}{C.RESET}")
    print(f"    Ethernet: {C.YELLOW}{'yes' if args.show_eth else 'no'}{C.RESET}")
    if args.count:
        print(f"    Count   : {C.YELLOW}{args.count}{C.RESET}")
    print()

    stats = Stats()

    if args.demo:
        demo_loop(args, stats)
    else:
        capture_loop(args, stats)

    print_stats(stats)
    print(f"  {C.DIM}Tip: run with --education for protocol reference{C.RESET}\n")


if __name__ == "__main__":
    main()
